MAGIC DRAGON PIN v0.10.74 — TEST

WHAT CHANGED IN v0.10.74
- Separated normal Delivery Sync from the legacy Whole App Snapshot test UI.
- Delivery Sync is now the primary cloud workflow; whole-app snapshot controls are tucked into a separate collapsed panel.
- Added Local / Cloud / Waiting delivery counts and a batch Sync Delivery Changes action.
- Record-level delivery changes no longer present themselves as a whole-app sync failure in the main workflow.
- Preserved per-record conflict protection and the advanced single-docket test control.

WHAT CHANGED IN v0.10.73
- Record-level delivery pull results now distinguish THIS pull from prior sync history.
- If nothing changed, message says all cloud dockets were already identical.
- New/updated cloud dockets are remembered and highlighted in Records.
- Delivery Records list now shows the docket ID so same-date/shop dockets can be distinguished.
- No record-sync architecture or business logic changed.

WHAT CHANGED IN v0.10.70
- Adds the first record-level Supabase sync Lego block for individual delivery dockets.
- Delivery records sync independently; this test does NOT replace the whole app database.
- Per-record revision protection blocks stale overwrites.
- Pulling delivery records safely adds new dockets or updates only records whose local base has not diverged.
- Local unsynced edits / true two-sided changes are left untouched and reported as conflicts.
- Existing whole-snapshot TEST Cloud sync remains available as the proven safety/reference path.
- Requires the one-time Magic-Pin-TEST-Delivery-Record-Setup-v1.sql migration in the DEV/TEST Supabase project.

TEST TARGET
1. Run the supplied SQL once in Magic Dragon Pin DEV Supabase.
2. On iPhone create a harmless test delivery docket in the normal New Delivery screen.
3. Settings > TEST Cloud Sync > Delivery Record Sync — TEST: select it and Upload selected docket.
4. On iPad sign in, Pull delivery records. The docket should appear without a whole-app restore.
5. Edit that same docket on iPad, then upload the selected docket again.
6. On iPhone Pull delivery records and verify the edited docket arrives.


v0.10.73
- Fixes iPad/tablet Settings shell so the Magic Dragon header remains visible while Settings content scrolls.
- Tablet-only shell patch; proven iPhone header/keyboard behaviour is left unchanged.
